export function Footer(){
  return (
    <footer className="text-center mt-8">
      <p>&copy; 2025 Raddy &middot; Build with NextJs</p>
    </footer>
  )
}