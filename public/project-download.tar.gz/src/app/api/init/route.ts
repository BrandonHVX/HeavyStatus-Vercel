import { NextResponse } from 'next/server';
import { initDatabase } from '@/lib/db';

export async function GET() {
  try {
    await initDatabase();
    return NextResponse.json({ success: true, message: 'Database initialized' });
  } catch (error: unknown) {
    console.error('Database init error:', error);
    const message = error instanceof Error ? error.message : 'Failed to initialize database';
    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
